﻿namespace QFSW.QC
{
    public enum AutoScrollOptions
    {
        Never = 0,
        OnInvoke = 1,
        Always = 2
    }
}