﻿namespace QFSW.QC
{
    /// <summary>
    /// The context that an action is being invoked on.
    /// </summary>
    public struct ActionContext
    {
        public QuantumConsole Console;
    }
}